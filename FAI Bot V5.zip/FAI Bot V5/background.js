async function getDocumentContent() {
    try {
        const response = await fetch(chrome.runtime.getURL("resources/techtalk07152021.txt"));
        const text = await response.text(); // Read response body as text
        const json = JSON.parse(text); // Parse as JSON
        // console.log("Extracted Transcription:", json.transcription);
        return json.transcription || "No transcription available."; // Return only the transcription
    } catch (error) {
        console.error("Error reading document:", error);
        return "Document could not be loaded.";
    }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "getAccessToken") {
        fetch("https://idcs-e56cf7f6ce36409298e59da0546b22a2.identity.pint.oc9qadev.com/oauth2/v1/token", {
            method: "POST",
            headers: {
                "Authorization": "Basic QUlBQ1NfQUlBUFBTX0lBRF9ERVZfQVBQSUQ6N2Q2NTk4NDMtMmY3Yy00NTUwLTg5M2EtMzE2NWY4MmYxOGJk",
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "grant_type=client_credentials&scope=https://idcs-e56cf7f6ce36409298e59da0546b22a2-fa.aiapps.ocs.oc-test.com/"
        })
        .then(response => response.json())
        .then(data => {
            sendResponse({ token: data.access_token });
        })
        .catch(error => {
            console.error("Fetch error:", error);
            sendResponse({ token: null });
        });

        return true; // Keeps sendResponse async
    }

    if (message.action === "sendChatRequest") {
        getDocumentContent().then((documentContent) => {
            const prompt = `
                Generate an answer to the given query in English. 
                Use relevant information from the provided document, which contains captions from a knowledge-sharing meeting held on Zoom by the Oracle Analytics Content Dev Infra Team. The meeting discussed how the team integrated Redis into the Oracle Analytics Product. 
    
                - If the document contains relevant details, prioritize that information in your response.  
                - If the document lacks necessary details, provide a general answer based on your knowledge.  
    
                Query: ${message.query}  
                Document: ${documentContent}
            `.trim();
    
            fetch("https://idcs-e56cf7f6ce36409298e59da0546b22a2-fa.aiapps.ocs.oc-test.com/ai-common/llm/rest/v1/completion", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${message.token}`
                },
                body: JSON.stringify({
                    "prompt": prompt,
                    "usecase": "hcm.pay.payslip_agent_prompt",
                    "properties": [
                        { "key": "query", "value": message.query },
                        { "key": "installed_language", "value": "English" }
                    ]
                })
            })
            .then(response => response.json())
            .then(data => {
                // console.log("LLM API Response:", data);
                sendResponse({ response: data.choices?.[0]?.text || "No response!" });
            })
            .catch(error => {
                console.error("Chat API error:", error);
                sendResponse({ response: "Error communicating with bot" });
            });
        })
        .catch(error => {
            console.error("Error loading document:", error);
            sendResponse({ response: "Error loading document for RAG." });
        });
    
        return true; // Keeps sendResponse async
    }
    
});

chrome.action.onClicked.addListener((tab) => {
    chrome.tabs.sendMessage(tab.id, { action: "openChatPanel" });
});

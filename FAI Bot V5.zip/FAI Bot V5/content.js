// Create the chat panel only if it doesn't exist
if (!document.getElementById("chat-panel")) {
    console.log("Content script loaded and panel is being created.");

    const panel = document.createElement("div");
    panel.id = "chat-panel";
    panel.innerHTML = `
        <style>
            #chat-panel {
                position: fixed;
                right: 0;  /* Positioning to the right */
                top: 0;
                width: 350px;
                height: 95vh;  /* Full height of the viewport */
                background: white;
                box-shadow: -2px 0 10px rgba(0, 0, 0, 0.2);  /* Shadow to the left */
                padding: 15px;
                display: flex;
                flex-direction: column;
                transition: transform 0.3s ease;
                transform: translateX(100%);  /* Start off-screen to the right */
                z-index: 9999;
            }
            #chat-panel.show {
                transform: translateX(0);  /* Show the panel when opened */
            }
            #chat-header {
                font-weight: bold;
                text-align: center;
                cursor: pointer;
            }
            #chat-messages {
                flex-grow: 1;
                overflow-y: auto;
                border: 1px solid #ccc;
                padding: 10px;
                margin-bottom: 10px;
                max-height: calc(100vh - 130px);  /* Adjust to fit header and input */
            }
            #chat-input {
                width: calc(100% - 22px);  /* Adjust width for padding and borders */
                padding: 10px;
                margin-bottom: 5px;  /* Add some space between input and button */
            }
            #send {
                width: 100%;
                padding: 10px;
                background: blue;
                color: white;
                border: none;
                cursor: pointer;
            }
        </style>
        <div id="chat-header">Chatbot (Click to Open/Close)</div>
        <div id="chat-messages"></div>
        <input type="text" id="chat-input" placeholder="Type a message..." />
        <button id="send">Send</button>
    `;
    document.body.appendChild(panel);

    // Add event listener to toggle the visibility of the panel
    document.getElementById("chat-header").addEventListener("click", () => {
        panel.classList.toggle("show"); // Toggle the class to show/hide the panel
    });

    // Add event listener for the send button and input
    document.getElementById("send").addEventListener("click", sendMessage);
    document.getElementById("chat-input").addEventListener("keypress", (e) => {
        if (e.key === "Enter") sendMessage();
    });
}

// Function to send a message
function sendMessage() {
    const input = document.getElementById("chat-input");
    const message = input.value.trim();
    if (!message) return;

    const messages = document.getElementById("chat-messages");
    messages.innerHTML += `<p><b>You:</b> ${message}</p>`;
    input.value = "";

    showTypingAnimation();

    chrome.runtime.sendMessage({ action: "getAccessToken" }, (response) => {
        if (!response || !response.token) {
            messages.innerHTML += "<p style='color:red;'>Failed to get access token!</p>";
            removeTypingAnimation();
            return;
        }

        const accessToken = response.token;

        chrome.runtime.sendMessage({ action: "sendChatRequest", query: message, token: accessToken }, (chatResponse) => {
            removeTypingAnimation();
            messages.innerHTML += `<p><b>Bot:</b> ${chatResponse.response}</p>`;
            messages.scrollTop = messages.scrollHeight;
        });
    });
}

// Function to show typing animation
function showTypingAnimation() {
    const messages = document.getElementById("chat-messages");
    const typing = document.createElement("p");
    typing.id = "typing-animation";
    typing.innerText = "Bot is typing...";
    messages.appendChild(typing);
    messages.scrollTop = messages.scrollHeight;
}

// Function to remove typing animation
function removeTypingAnimation() {
    const typing = document.getElementById("typing-animation");
    if (typing) typing.remove();
}

// Listener for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "openChatPanel") {
        const panel = document.getElementById("chat-panel");
        if (panel) {
            panel.classList.toggle("show"); // Toggle visibility of the panel when opened
        }
    }
});
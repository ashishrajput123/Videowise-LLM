import os
import json

TRANSCRIPT_FILE = "resources/sample.txt"  # Adjust the path if needed

def get_transcript():
    """Reads and extracts the 'transcript' content from the JSON file."""
    try:
        with open(TRANSCRIPT_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)  # Parse JSON
        return data.get("transcript", "No transcript available.")  # Extract transcript value
    except FileNotFoundError:
        print("Transcript file not found.")
        return "No transcript available."
    except json.JSONDecodeError:
        print("Error decoding JSON from transcript file.")
        return "Error parsing transcript file."
    except Exception as e:
        print(f"Error reading transcript: {e}")
        return "Error loading transcript."

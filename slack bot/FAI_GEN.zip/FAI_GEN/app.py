import oci
import json
import requests
import threading
from flask import Flask, request, jsonify
from oci.generative_ai_agent_runtime import GenerativeAiAgentRuntimeClient
from oci.generative_ai_agent_runtime.models import ChatDetails
from config import SLACK_BOT_TOKEN, OCI_AGENT_ENDPOINT_ID
import os

app = Flask(__name__)
processed_events = set()
SESSION_FILE = "session.json"

# Load OCI config
print("Loading OCI configuration...")
config = oci.config.from_file("~/.oci/config", "<PROFILE_NAME>")
print("OCI configuration loaded.")

# Initialize Generative AI Agent Runtime Client
generative_ai_agent_runtime_client = GenerativeAiAgentRuntimeClient(config)
print("OCI Generative AI Agent Runtime Client initialized.")

def load_session():
    """Loads session ID from session.json if available."""
    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, "r") as file:
                data = json.load(file)
                return data.get("session_id")  # e.g. "ocid1.genaiagentsession.oc1.<region>.<masked>"
        except Exception as e:
            print(f"⚠️ Failed to load session file: {e}")
    return None

def save_session(session_id):
    """Saves session ID to session.json."""
    try:
        with open(SESSION_FILE, "w") as file:
            json.dump({"session_id": session_id})  # Masked before upload
    except Exception as e:
        print(f"⚠️ Failed to save session file: {e}")

def create_session():
    """Creates a new session and saves it."""
    global session_id
    print("🔄 Creating a new session...")
    try:
        response = generative_ai_agent_runtime_client.create_session(
            agent_endpoint_id=OCI_AGENT_ENDPOINT_ID,  # e.g. "ocid1.genaiagentendpoint.oc1.<region>.<masked>"
            create_session_details={}
        )
        session_id = response.data.id
        print(f"✅ New session created: {session_id}")
        save_session(session_id)
    except Exception as e:
        print(f"❌ Error creating session: {e}")
        session_id = None

@app.route("/slack/events", methods=["POST"])
def slack_events():
    data = request.json

    if "challenge" in data:
        return jsonify({"challenge": data["challenge"]})

    if request.headers.get("X-Slack-Retry-Num"):
        print("Ignoring Slack retry attempt")
        return jsonify({"status": "ignored"}), 200

    event_id = data.get("event_id")
    if event_id in processed_events:
        print(f"Ignoring duplicate event: {event_id}")
        return jsonify({"status": "ignored"}), 200
    processed_events.add(event_id)

    event = data.get("event", {})
    if "bot_id" in event:
        print("Ignoring bot message.")
        return jsonify({"status": "ignored"}), 200

    threading.Thread(target=handle_slack_event, args=(event,)).start()
    return jsonify({"status": "ok"}), 200

def handle_slack_event(event):
    global session_id
    user_message = event.get("text", "")
    channel = event.get("channel", "")
    print(f"💬 Processing message: {user_message} in channel: {channel}")

    if not session_id:
        session_id = load_session()

    if not session_id:
        create_session()

    if not session_id:
        print("❌ Failed to create session, aborting request.")
        return

    try:
        chat_details = ChatDetails(
            user_message=user_message,
            should_stream=False,
            session_id=session_id
        )
        
        print(f"🟢 Sending request to OCI Generative AI Agent with chat details.")

        response = generative_ai_agent_runtime_client.chat(
            agent_endpoint_id=OCI_AGENT_ENDPOINT_ID,
            chat_details=chat_details
        )

        print(f"🟢 Full response from OCI Generative AI Agent received.")

        generation_text = "I'm sorry, but I couldn't generate a response."
        for trace in reversed(response.data.traces or []):
            if hasattr(trace, "generation") and trace.generation:
                generation_text = trace.generation
                break

    except oci.exceptions.ServiceError as e:
        print(f"❌ OCI Service Error: {e}")

        if e.status == 404:
            print("⚠️ Session not found. Creating a new session...")
            create_session()
            return handle_slack_event(event)
        elif e.status == 409:
            print("⚠️ Session conflict detected, creating a new session.")
            create_session()
            return handle_slack_event(event)
        elif e.status == 400 and "Inappropriate content" in e.message:
            generation_text = "⚠️ Your message triggered an inappropriate content filter. Please rephrase."
        else:
            generation_text = f"❌ Error fetching response: {str(e)}"
    
    except Exception as e:
        generation_text = f"❌ Unexpected error: {str(e)}"
        print(generation_text)

    send_slack_message(channel, generation_text)

def send_slack_message(channel, text):
    print(f"📤 Sending message to Slack: {text} in channel: {channel}")
    slack_webhook_url = "https://slack.com/api/chat.postMessage"
    headers = {
        "Authorization": f"Bearer {SLACK_BOT_TOKEN}",  # Masked value: "<SLACK_BOT_TOKEN>"
        "Content-Type": "application/json"
    }
    data = json.dumps({"channel": channel, "text": text})
    response = requests.post(slack_webhook_url, headers=headers, data=data)
    print(f"✅ Slack response: {response.status_code} - {response.text}")

if __name__ == "__main__":
    print("🚀 Starting Flask server...")
    session_id = load_session()
    app.run(port=3000, debug=True)
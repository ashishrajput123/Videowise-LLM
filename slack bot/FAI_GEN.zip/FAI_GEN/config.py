SLACK_BOT_TOKEN = "xoxb-****-****-********************"
OCI_AGENT_ENDPOINT_ID = "ocid1.genaiagentendpoint.oc1.us-****-1.********************"
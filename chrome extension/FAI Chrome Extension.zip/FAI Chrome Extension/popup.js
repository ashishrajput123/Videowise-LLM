document.addEventListener("DOMContentLoaded", function () {
    // This script will send a message to the content script to open the chat panel
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, { action: "openChatPanel" });
    });
    window.close(); // Close the popup immediately after sending the message
});
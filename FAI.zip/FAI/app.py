from flask import Flask, request, jsonify
import requests
import threading
import json
from process_transcript import get_transcript
from config import SLACK_BOT_TOKEN, LLM_ENDPOINT, OAUTH_TOKEN_URL, CLIENT_CREDENTIALS

app = Flask(__name__)

def get_access_token():
    """ Fetches the access token required for LLM API calls. """
    try:
        response = requests.post(
            OAUTH_TOKEN_URL,
            headers={
                "Authorization": f"Basic {CLIENT_CREDENTIALS}",
                "Content-Type": "application/x-www-form-urlencoded"
            },
            data={
                "grant_type": "client_credentials",
                "scope": "https://idcs-e56cf7f6ce36409298e59da0546b22a2-fa.aiapps.ocs.oc-test.com/"
            }
        )
        response_json = response.json()
        # print("Access Token Response:", json.dumps(response_json, indent=2))  # Debugging
        return response_json.get("access_token")
    except Exception as e:
        print("Error fetching access token:", str(e))
        return None


def query_llm(user_query, access_token):
    """ Sends the user's query and transcript to the LLM endpoint. """
    transcript = get_transcript()

    prompt = f"""
    Generate an answer to the given query in English.
    Use relevant information from the provided document, which contains captions from a knowledge-sharing meeting held on Zoom by the Oracle Analytics Content Dev Infra Team. The meeting discussed how the team integrated Redis into the Oracle Analytics Product.

    - If the document contains relevant details, prioritize that information in your response.
    - If the document lacks necessary details, provide a general answer based on your knowledge.

    Query: {user_query}
    Document: {transcript}
    """.strip()

    # print(f"Sending request to LLM with prompt:\n{prompt}")  # Debugging

    try:
        response = requests.post(
            LLM_ENDPOINT,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {access_token}"
            },
            json={
                "prompt": prompt,
                "usecase": "hcm.pay.payslip_agent_prompt",
                "properties": [
                    {"key": "query", "value": user_query},
                    {"key": "installed_language", "value": "English"}
                ]
            }
        )
        
        response_json = response.json()
        # print("LLM Response:", json.dumps(response_json, indent=2))  # Debugging
        
        # Safely extract the text response
        choices = response_json.get("choices", [])
        if choices and isinstance(choices, list) and "text" in choices[0]:
            return choices[0]["text"]
        
        return "No response from LLM!"
    
    except Exception as e:
        print(f"Error fetching LLM response: {str(e)}")
        return f"Error fetching LLM response: {str(e)}"

def send_slack_message(channel, text):
    """ Sends a message to the specified Slack channel. """
    url = "https://slack.com/api/chat.postMessage"
    headers = {
        "Authorization": f"Bearer {SLACK_BOT_TOKEN}",
        "Content-Type": "application/json"
    }
    data = json.dumps({"channel": channel, "text": text})
    
    # print(f"Sending Slack message: {text} to channel {channel}")  # Debugging
    
    response = requests.post(url, headers=headers, data=data)
    response_json = response.json()
    
    # print("Slack API Response:", json.dumps(response_json, indent=2))  # Debugging
    
    if not response_json.get("ok"):
        print(f"Error sending message to Slack: {response_json}")
    
    return response_json

processed_events = set()  # Track processed event IDs

def handle_slack_event(data):
    """ Process the Slack event asynchronously. """
    event_id = data.get("event_id")

    if event_id in processed_events:
        print(f"Ignoring duplicate event: {event_id}")
        return

    processed_events.add(event_id)  # Mark event as processed

    event = data.get("event", {})
    
    if event.get("type") == "message" and "subtype" not in event:
        user_query = event.get("text", "")
        channel = event.get("channel")

        if user_query and channel:
            print(f"Received message: {user_query} in channel: {channel}")

            # Fetch LLM response
            access_token = get_access_token()
            if access_token:
                response_text = query_llm(user_query, access_token)
                send_slack_message(channel, response_text)
            else:
                send_slack_message(channel, "Error: Unable to retrieve access token.")

@app.route("/slack/events", methods=["POST"])
def slack_events():
    data = request.json

    # **Immediately acknowledge the event**
    if "challenge" in data:
        return jsonify({"challenge": data["challenge"]})
    # print ("data : ", data)
    if request.headers.get("X-Slack-Retry-Num"):
        print("Ignoring Slack retry attempt")
        return jsonify({"status": "ignored"}), 200  # Ignore retries
    
    event = data.get("event", {})

    # Ignore messages sent by bots (including itself)
    if "bot_id" in event:
        print("Ignoring bot message.")
        return jsonify({"status": "ignored"}), 200

    # Check for duplicate event
    event_id = data.get("event_id")
    if event_id in processed_events:
        print(f"Ignoring duplicate event: {event_id}")
        return jsonify({"status": "ignored"}), 200

    # Process the event in a separate thread
    threading.Thread(target=handle_slack_event, args=(data,)).start()

    return jsonify({"status": "ok"}), 200  # Immediate response to Slack



if __name__ == "__main__":
    app.run(port=3000, debug=True)
